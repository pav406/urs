﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using shape;

namespace labbook4_2
{
    class Program
    {
        static void Main(string[] args)
        {
            //Shape.Shape s = new Triangle();
            //s.WhoamI();
            //Shape.Shape s1 = new Circle();
            //s1.WhoamI();
            //Console.ReadKey();
            shape.Shape s = new Triangle();
            s.WhoamI();
            shape.Shape s1 = new Triangle();
            s1.WhoamI();
            Console.ReadKey();

        }
    }
}
