﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace employee
{
    public abstract class employee
    {
        protected int employeeId;
        protected string employeeName, address, city, department;
        protected double salary;
        abstract public void GetSalary();
    }

    public class ContractEmployee : employee
    {
        int perk = 1000;
        public int Perk
        {
            set { perk = value; }
            get { return perk; }

        }

        public void AcceptData()
        {           
            Console.WriteLine("Enter Details of Contract Employee");
            Console.WriteLine("Enter employee Id");
            employeeId = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter employee name");
            employeeName = Console.ReadLine();
            Console.WriteLine("Enter employee Address");
            address = Console.ReadLine();
            Console.WriteLine("Enter employee city");
            city = Console.ReadLine();
            Console.WriteLine("Enter employee department");
            department = Console.ReadLine();
            Console.WriteLine("Enter employee salary");
            salary = Convert.ToDouble(Console.ReadLine());
            Perk = 1000;
        }

        public override void GetSalary()
        {
            salary = salary + Perk;
        }
        public void DisplayData()
        {            
            Console.WriteLine("Details of Contract Employee");
            Console.WriteLine("employee Id : " + employeeId);
            Console.WriteLine("mployee name : " + employeeName);
            Console.WriteLine("employee Address : " + address);
            Console.WriteLine("employee city : " + city);
            Console.WriteLine("employee department : " + department);
            Console.WriteLine("employee salary : " + salary);            
        }
    }


    public class PermanentEmployee : employee
    {
        int fund;
        public int ProvidentFund
        {
            set { fund = value; }
            get { return fund; }

        }

        int leaves;
        public int NoOfLeaves
        {
            set { leaves = value; }
            get { return leaves; }

        }
        public void AcceptData()
        {
            
            Console.WriteLine("Enter Details of Permanent Employee");
            Console.WriteLine("Enter employee Id");
            employeeId = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter employee name");
            employeeName = Console.ReadLine();

            Console.WriteLine("Enter employee Address");
            address = Console.ReadLine();

            Console.WriteLine("Enter employee city");
            city = Console.ReadLine();

            Console.WriteLine("Enter employee department");
            department = Console.ReadLine();

            Console.WriteLine("Enter employee salary");
            salary = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("Enter leaves");
            NoOfLeaves = Convert.ToInt32(Console.ReadLine());
            ProvidentFund = 1000;
        }

        public override void GetSalary()
        {
            salary = salary - ProvidentFund;
        }

        public void DisplayData()
        {
            Console.WriteLine(" Permanent Employee details");
            Console.WriteLine("employee Id : " + employeeId);
            Console.WriteLine("mployee name : " + employeeName);
            Console.WriteLine("employee Address : " + address);
            Console.WriteLine("employee city : " + city);
            Console.WriteLine("employee department : " + department);
            Console.WriteLine("employee salary : " + salary);
            Console.WriteLine("total leaves : " + NoOfLeaves);
        }
    }
}
