﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Labbook4_3
{
    class Program
    {
        public class Shape
        {
            public virtual void WhoamI()
            {
                Console.WriteLine("I m Shape");
            }
        }
        public class Triangle : Shape
        {
            public override void WhoamI()
            {
                Console.WriteLine("I m Triangle");
            }
        }
        public class Circle : Shape
        {
            public new void WhoamI()
            {
                Console.WriteLine("I m Circle");
            }
        }
        static void Main(string[] args)
        {
            Shape s = new Triangle();
            s.WhoamI();
            Shape s1 = new Circle();
            s1.WhoamI();
            Circle s2 = new Circle();
            s2.WhoamI();
            Console.ReadKey();
        }
    }
}
